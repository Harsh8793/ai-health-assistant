from home import show_home

if __name__ == "__main__":
    show_home()
